package runtympoly;

 class runp1 {
	
	 
		void draw() 
		{
			System.out.println("drawing..."); 
		}
		}


class Rectangle extends runp1 
{ 
	void draw() 
	{
		System.out.println("drawing rectangle");
	} 
	} 
class Circle extends runp1 
{ 
	void draw() 
	{
		System.out.println("drawing circle...");
		}
	}
class Triangle extends runp1 
{
	void draw() 
	{
		System.out.println("drawing triangle..."); 
		}
	}
public class runp 
{ 
	public static void main(String args[]) 
	{ 
		runp1 s; 
		s = new Rectangle();
		s.draw(); 
		s = new Circle();
		s.draw(); 
		s = new Triangle(); 
		s.draw(); 
		} 
		}