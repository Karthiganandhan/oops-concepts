package runtympoly;

 class Bike 
{

		int speedlimit = 90;
		}
	public class runex2 extends Bike
	{ 
		int speedlimit = 150;
		public static void main(String args[])
		{ 
			Bike obj = new runex2(); 
			System.out.println(obj.speedlimit);
	}
	}


