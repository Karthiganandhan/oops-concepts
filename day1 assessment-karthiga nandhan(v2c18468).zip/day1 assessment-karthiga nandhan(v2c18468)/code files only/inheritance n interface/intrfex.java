import java.io.IOException;

interface pri
{
public void print();
}
class intrfex implements pri
{
public void print()
{
int i,m=0,f=0;
int n=7;
m=n/2;
if(n==0||n==1)
{
System.out.println(n+" is not prime");
}
else
{
for(i=2;i<=m;i++)
{
if(n%i==0)
{
System.out.println(n+" is not prime");
f=1;
break;
}
}
if(f==0)
{
System.out.println(n+" is prime");
}
}
}
public static void main(String args[])throws IOException
{
intrfex l=new intrfex();
l.print();
}}
